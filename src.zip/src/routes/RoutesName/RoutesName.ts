export enum ROUTES {
  Login = 'Login',
  TabGroup = "TabGroup",
  Home="Home",
  Favourite="Favourite"
}
