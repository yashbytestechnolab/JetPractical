export const emailCredential = "reactnative@jetdevs.com";
export const passwordCredential = "jetdevs@123"