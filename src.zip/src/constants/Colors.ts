export const Colors = {
  white: '#FFFFFF',
  whiteShadow: '#f3f5fb',
  primary: '#E12B6E',
  midGrey: "#444444",
  offWhite: "#d1d3db",
  locationGray:'#8a8a8a',

};
