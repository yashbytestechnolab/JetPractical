export const strings = {
    home: "Home",
    favourite: "Favourite",
    login: "LOGIN",
    email: "Email",
    password: "Password"
}