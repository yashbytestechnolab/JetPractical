export const icon = {
    home: require('./home.png'),
    homeFocused: require('./homeFocused.png'),
    favourite: require('./Favourite.png'),
    favouriteFocused: require('./FavouriteFocused.png'),
    logo: require('./logo.png'),
    email: require('./email.png'),
    password: require('./password.png'),
    location: require('./location.png'),
}